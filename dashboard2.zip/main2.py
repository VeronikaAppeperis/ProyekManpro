import os
import sys
from dashboard2 import Ui_dashboard2
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import *
from PyQt5.QtChart import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import QtCore, QtGui, QtWidgets

class MainWindow:
    def __init__(self):
        self.main_win=QMainWindow()
        self.ui=Ui_dashboard2()
        self.ui.setupUi(self.main_win)
        #loadJsonStyle(self, self.ui)
        self.ui.stackedWidget.setCurrentWidget(self.ui.prediction)
        self.ui.hbc_button.clicked.connect(self.show_hbc)
        self.ui.pc_button.clicked.connect(self.show_pc)
        self.ui.hm_button.clicked.connect(self.show_nd)
        self.ui.lc_button.clicked.connect(self.show_lc)
        self.ui.bc_button.clicked.connect(self.show_bc)
        self.ui.prediction_button.clicked.connect(self.show_prediction)
        self.Side_menu_num=0
        self.ui.menuButton.clicked.connect(self.showmenu)

        
    def showmenu(self):
        if self.Side_menu_num==0:
            self.animation1=QtCore.QPropertyAnimation(self.ui.left_menu_widget, b"maximumWidth") 
            self.animation1.setDuration(500)
            self.animation1.setStartValue(58)
            self.animation1.setEndValue(130)
            self.animation1.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation1.start()
            self.Side_menu_num=1
        else:
            self.animation2=QtCore.QPropertyAnimation(self.ui.left_menu_widget, b"maximumWidth") 
            self.animation2.setDuration(500)
            self.animation2.setStartValue(130)
            self.animation2.setEndValue(58)
            self.animation2.setEasingCurve(QtCore.QEasingCurve.InOutQuart)
            self.animation2.start()
            self.Side_menu_num=0

    def show(self):
        self.main_win.show()

    def show_hbc(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.hbc)
    def show_pc(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.pc)
    def show_lc(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.lc)
    def show_bc(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.bc)
    def show_nd(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.hm)
    def show_prediction(self):
        self.ui.stackedWidget.setCurrentWidget(self.ui.prediction)
    
if __name__=='__main__':
    app=QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec_())

# app = QApplication(sys.argv)
# window = QMainWindow()
# ui = Ui_MainWindow()
# ui.setupUi(window)


# window.show()
# sys.exit(app.exec_())