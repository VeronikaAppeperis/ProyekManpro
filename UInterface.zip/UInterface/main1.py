import os
import sys
from uidb import Ui_MainWindow
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtGui import *
from PyQt5.QtChart import *
from PyQt5.QtWidgets import *

class MainWindow:
    def __init__(self):
        self.main_win=QMainWindow()
        self.ui=Ui_MainWindow()
        self.ui.setupUi(self.main_win)
        
        self.loadData()
        self.ui.pushButton.clicked.connect(self.data_save)

# nyimpen text yang di input trus dimasukin ke table
    def data_save(self):
        companyName = self.ui.lineEdit.text()
        category = self.ui.lineEdit_2.text()
        funding = self.ui.lineEdit_3.text()
        country = self.ui.lineEdit_4.text()
        status = self.ui.comboBox.currentText()

        if companyName and category and funding and country and status is not None:
            rowCount = self.ui.tableWidget.rowCount()
            self.ui.tableWidget.insertRow(rowCount)
            self.ui.tableWidget.setItem(rowCount,0, QTableWidgetItem(companyName))
            self.ui.tableWidget.setItem(rowCount,1, QTableWidgetItem(category))
            self.ui.tableWidget.setItem(rowCount,2, QTableWidgetItem(funding))
            self.ui.tableWidget.setItem(rowCount,3, QTableWidgetItem(country))
            self.ui.tableWidget.setItem(rowCount,4, QTableWidgetItem(status))

    def loadData(self):
        self.ui.tableWidget.setRowCount(3)
        self.ui.tableWidget.setColumnCount(5)
        self.ui.tableWidget.setHorizontalHeaderLabels(('Company Name', 'Category', 'Funding', 'Country', 'Status'))
        
        self.ui.tableWidget.setItem(0,0, QTableWidgetItem('ZenChef'))
        self.ui.tableWidget.setItem(0,1, QTableWidgetItem('Restaurant'))
        self.ui.tableWidget.setItem(0,2, QTableWidgetItem('106000000'))
        self.ui.tableWidget.setItem(0,3, QTableWidgetItem('France'))
        self.ui.tableWidget.setItem(0,4, QTableWidgetItem('Operating'))

        self.ui.tableWidget.setItem(1,0, QTableWidgetItem('Karma Gaming'))
        self.ui.tableWidget.setItem(1,1, QTableWidgetItem('Gaming'))
        self.ui.tableWidget.setItem(1,2, QTableWidgetItem('48300000'))
        self.ui.tableWidget.setItem(1,3, QTableWidgetItem('Great Britain'))
        self.ui.tableWidget.setItem(1,4, QTableWidgetItem('Operating'))

        self.ui.tableWidget.setItem(2,0, QTableWidgetItem('Pinstant Karma'))
        self.ui.tableWidget.setItem(2,1, QTableWidgetItem('Sosial Media'))
        self.ui.tableWidget.setItem(2,2, QTableWidgetItem('-'))
        self.ui.tableWidget.setItem(2,3, QTableWidgetItem('USA'))
        self.ui.tableWidget.setItem(2,4, QTableWidgetItem('Closed'))

        # ukuran per coloumn
        self.ui.tableWidget.setColumnWidth(0,150)
        self.ui.tableWidget.setColumnWidth(1,150)
        self.ui.tableWidget.setColumnWidth(2,150)
        self.ui.tableWidget.setColumnWidth(3,150)
        self.ui.tableWidget.setColumnWidth(4,150)

    def show(self):
        self.main_win.show()

if __name__=='__main__':
    app=QApplication(sys.argv)
    main_win = MainWindow()
    main_win.show()
    sys.exit(app.exec_())